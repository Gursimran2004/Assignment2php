<footer>
<div class="footerContainer" >
  
  <div class="socialIcons">
   <a href=""><i class="fa-brands fa-facebook"></i></a>
   <a href=""><i class="fa-brands fa-instagram"></i></a>
   <a href=""><i class="fa-brands fa-twitter"></i></a>
   <a href=""><i class="fa-brands fa-google-plus"></i></a>
   <a href=""><i class="fa-brands fa-youtube"></i></a>

  </div>
  <div class="footerNav">
        <ul>
          <li><a href="user_login.php">Home</a></li>
          <li><a href="user_login.php#portfolio">News</a></li>
          <li><a href="user_login.php#about">About</a></li>
          <li><a href="user_login.php#contact">Contact Us</a></li>
          <li><a href="user_login.php#team">Our Team</a></li>
        </ul>
    </div>
    <div class="footerBottom">
        <p>Copyright &copy;2023; Designed by <span class="designer">Gursimran</p>

    </div>
</div>


</footer>
</div>
</body>

</html>